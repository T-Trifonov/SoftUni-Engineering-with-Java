package aquarium;

import java.util.ArrayList;
import java.util.List;

public class Aquarium {

    private String name;
    private int capacity;
    private int size;
    private List<aquarium.Fish> fishInPool;

    public Aquarium(String name, int capacity, int size) {
        this.name = name;
        this.capacity = capacity;
        this.size = size;
        this.fishInPool = new ArrayList<>();
    }


    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getSize() {
        return size;
    }

    public int getFishInPool(){
        return fishInPool.size();
    }

    public void add(aquarium.Fish fish){
        if (fishInPool.size()+1<=getCapacity()){
            if (!fishInPool.contains(fish)){
                fishInPool.add(fish);
            }
        }
    }

    public boolean remove(String name){
        boolean isRemove = false;
        for (int i = 0; i < fishInPool.size(); i++) {
            if (fishInPool.get(i).getName().equals(name)){
                fishInPool.remove(i);
                isRemove=true;
                break;
            }
        }

        return isRemove;
    }

    public aquarium.Fish findFish(String name){
        for (aquarium.Fish current : fishInPool) {
            if (current.getName().equals(name)){
                return current;
            }
        }

        return null;
    }

    public String report(){
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Aquarium: %s ^ Size: %d", this.name, this.size));
        sb.append(System.lineSeparator());
        for (aquarium.Fish current : fishInPool) {
            sb.append(current.toString());
            sb.append(System.lineSeparator());
        }

        return sb.toString();

    }

}
