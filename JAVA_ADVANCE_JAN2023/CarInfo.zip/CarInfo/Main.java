package CarInfo;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numCars = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < numCars; i++) {

            String[] input = scanner.nextLine().split("\\s+");

            if (input.length>1) {

                Car carIndex = new Car(getString(input, 0), getString(input, 1),
                        Integer.parseInt(getString(input, 2)));
                Car.addCar(carIndex);
            } else {
                Car carIndex = new Car(getString(input, 0));
                Car.addCar(carIndex);
            }

        }

        Car.report();

    }

//--//

    private static String getString(String[] input, int position) {
        String value ="";
        if (!input[position].isEmpty()) {
            value = input[position];
        }
        return value;
    }

}
