package CarInfo;

import java.util.ArrayList;
import java.util.List;

public class Car {

    private String brand;
    private String Model;
    private int Horsepower;

    public Car(String brand, String model, int horsepower) {
        this.brand = brand;
        Model = model;
        Horsepower = horsepower;
    }

    public Car(String brand) {
        this(brand, "unknown", -1);
    }

    public static List<Car> base = new ArrayList<>();

    public static void addCar(Car car){
        base.add(car);
    }

    public static void report(){
        base.forEach(el -> System.out.print(el));

    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return Model;
    }

    public int getHorsepower() {
        return Horsepower;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setModel(String model) {
        Model = model;
    }

    public void setHorsepower(int horsepower) {
        Horsepower = horsepower;
    }

    @Override
    public String toString() {
        return String.format("The car is: %s %s - %d HP.%n", getBrand(), getModel(), getHorsepower());
    }

    public String carInfo() {
        return toString();
    }

}
