package kindergarten;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Kindergarten {

    private String name;
    private int capacity;
    private List<Child> registry;

    public Kindergarten(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.registry = new ArrayList<>(capacity);
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getChildrenCount() {
        return registry.size();
    }

    public boolean addChild(Child child) {
        if (registry.size() < capacity) {
            registry.add(child);
            return true;
        }
        return false;
    }

    public boolean removeChild(String firstName) {

        for (int i = 0; i < registry.size(); i++) {
            if (registry.get(i).getFirstName().equals(firstName)) {
                registry.remove(i);
                return true;

            }
        }

        return false;

    }

    public Child getChild(String firstName) {

        for (int i = 0; i < registry.size(); i++) {
            if (registry.get(i).getFirstName().equals(firstName)) {
                return registry.get(i);
            }
        }

        return null;

    }

    public String registryReport() {

        registry = registry.stream().sorted(Comparator.comparing(Child::getAge).thenComparing(Child::getFirstName).thenComparing(Child::getLastName)).collect(Collectors.toList());

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Registered children in %s", getName()));
        sb.append(System.lineSeparator());
        sb.append("--");
        sb.append(System.lineSeparator());
        for (int i = 0; i < registry.size(); i++) {
            sb.append(registry.get(i));
            sb.append(System.lineSeparator());
            if (i!=registry.size()-1) {
                sb.append("--");
                sb.append(System.lineSeparator());
            }
        }

        return sb.toString();
    }

}
