package BankAccount;

public class BankAccount {

    private final static double DEFAULT_INTEREST_RATE = 0.02;
    private static double interestRate = DEFAULT_INTEREST_RATE;
    private static int bankAccountCount = 1;
    private int id;
    private double balance;

    public BankAccount(){
        this.id= bankAccountCount++;
        this.balance=0;
    }

    public void deposit(double amount){
        balance+=amount;
    }

    public double getInterest(int Years){
        return balance*Years*interestRate;
    }

    public static void setInterestRate(double interest){
        interestRate=interest;
    }

    public int getId(){
        return this.id;
    }


}
