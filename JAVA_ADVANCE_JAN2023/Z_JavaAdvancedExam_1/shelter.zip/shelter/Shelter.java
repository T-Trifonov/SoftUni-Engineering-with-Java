package shelter;

import java.util.*;

public class Shelter {

    private List<Animal> data;
    private int capacity;

    public Shelter(int capacity) {
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public void add(Animal animal) {
        if (data.size() + 1 > data.size()) {
            data.add(animal);
        }
    }

    public int getCount() {
        return data.size();
    }

    public boolean remove(String name) {

        for (int i = 0; i < getCount(); i++) {
            if (data.get(i).getName().equals(name)) {
                data.remove(i);
                return true;
            }

        }

        return false;

    }

    public Animal getAnimal(String name, String caretaker){

        for (int i = 0; i < getCount(); i++) {
            if (data.get(i).getName().equals(name)){
                if(data.get(i).getCaretaker().equals(caretaker)){
                    return data.get(i);
                }
            }
        }

        return null;

    }

    public Animal getOldestAnimal(){
        int oldest = Integer.MIN_VALUE;
        int position = 0;

        for (int i = 0; i < getCount(); i++) {
            if (data.get(i).getAge()>oldest){
                oldest=data.get(i).getAge();
                position=i;

            }
        }

        return data.get(position);

    }

    public String getStatistics(){
        StringBuilder sb = new StringBuilder();

        if (getCount()>0){
            sb.append("The shelter has the following animals:");
            sb.append(System.lineSeparator());
        }

        for (int i = 0; i < getCount(); i++) {
            String name = String.format(data.get(i).getName());
            String character = String.format(data.get(i).getCaretaker());
            sb.append(name);
            sb.append(" ");
            sb.append(character);
            sb.append(System.lineSeparator());
        }

        return sb.toString();

    }
}
