package T06Animals;

import java.util.Scanner;
import java.util.SimpleTimeZone;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);


        String animalType = scanner.nextLine();

        while (!animalType.equals("Beast!")) {

            String[] animalParameters = scanner.nextLine().split("\\s+");
            try {
                if (animalType.equals("Dog")) {
                    Dog dog = new Dog(animalParameters[0], Integer.parseInt(animalParameters[1]), animalParameters[2]);
                    System.out.println(dog);
                } else if (animalType.equals("Frog")) {
                    Frog frog = new Frog(animalParameters[0], Integer.parseInt(animalParameters[1]), animalParameters[2]);
                    System.out.println(frog);
                } else if (animalType.equals("Cat")) {
                    Cat cat = new Cat(animalParameters[0], Integer.parseInt(animalParameters[1]), animalParameters[2]);
                    System.out.println(cat);
                } else if (animalType.equals("Tomcat")) {
                    Tomcat tomcat = new Tomcat(animalParameters[0], Integer.parseInt(animalParameters[1]));
                    System.out.println(tomcat);
                } else if (animalType.equals("Kitten")) {
                    Kitten kitten = new Kitten(animalParameters[0], Integer.parseInt(animalParameters[1]));
                    System.out.println(kitten);
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
            animalType = scanner.nextLine();
        }


    }
}
