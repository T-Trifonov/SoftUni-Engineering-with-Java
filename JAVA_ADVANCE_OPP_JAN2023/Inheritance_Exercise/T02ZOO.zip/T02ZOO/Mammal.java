package T02ZOO;

public class Mammal extends Animal{
    public Mammal(String name) {
        super(name);
    }
}
