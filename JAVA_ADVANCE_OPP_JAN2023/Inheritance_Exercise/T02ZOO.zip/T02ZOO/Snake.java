package T02ZOO;

public class Snake extends Reptile{
    public Snake(String name) {
        super(name);
    }
}
