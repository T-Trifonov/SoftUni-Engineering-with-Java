package T02ZOO;

public class Bear extends Mammal{

    public Bear(String name) {
        super(name);
    }
}
