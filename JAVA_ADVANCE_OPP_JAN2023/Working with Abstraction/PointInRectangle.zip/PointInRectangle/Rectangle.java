package A_WorkingWithAbstraction.PointInRectangle;

public class Rectangle {

    private int X1;
    private int Y1;

    private int X2;
    private int Y2;

    public Rectangle(int x1, int y1, int x2, int y2) {
        X1 = x1;
        Y1 = y1;
        X2 = x2;
        Y2 = y2;
    }

    public boolean contains(Point point){

        return point.getX() >=X1 && point.getX()<=X2 && point.getY()>=Y1 && point.getY()<=Y2;

    }



}
