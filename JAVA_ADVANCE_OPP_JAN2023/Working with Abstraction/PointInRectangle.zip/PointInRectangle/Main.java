package A_WorkingWithAbstraction.PointInRectangle;

import java.util.*;

public class Main {

    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);

        int[] coordinates = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(el -> Integer.parseInt(el))
                .toArray();

        Rectangle rectangle = new Rectangle(coordinates[0], coordinates[1], coordinates[2], coordinates[3]);

        int numPoints = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < numPoints; i++) {

            int[] coordinatesPoint = Arrays.stream(scanner.nextLine().split(" "))
                    .mapToInt(el -> Integer.parseInt(el))
                    .toArray();

            Point points = new Point(coordinatesPoint[0], coordinatesPoint[1]);

            System.out.println(rectangle.contains(points));

        }


    }

}
