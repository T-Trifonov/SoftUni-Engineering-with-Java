package T01CarShop;

public interface Sellable extends Car{
    Double getPrice();
}
