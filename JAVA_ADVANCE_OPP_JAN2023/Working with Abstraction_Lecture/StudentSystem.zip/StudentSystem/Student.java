package StudentSystem;

public class Student {
    private String name;
    private int age;
    private double grade;

    public void student(String name, int age, double grade) {
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    public double getGrade() {
        return this.grade;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        String temp = String.format("%s is %s years old.", getName(), getAge());

        sb.append(temp);

        if (getGrade() >= 5.00) {
            temp = " Excellent student.";
        } else if (getGrade() < 5.00 && getGrade() >= 3.50) {
            temp = " Average student.";
        } else {
            temp = " Very nice person.";
        }

        sb.append(temp);

        return sb.toString();

    }
}

