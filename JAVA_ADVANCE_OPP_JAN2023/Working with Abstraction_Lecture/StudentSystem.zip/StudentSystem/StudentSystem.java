package StudentSystem;

import java.util.HashMap;
import java.util.Map;

public class StudentSystem {
    private Map<String, Student> repo;

    public StudentSystem() {
        this.repo = new HashMap<>();
    }

    public void createStudent(Student student) {

        if (!this.repo.containsKey(student.getName())) {
            repo.put(student.getName(), student);
        }
    }

    public void showStudent(String name){

        if (repo.containsKey(name)){
            System.out.println(repo.get(name).toString());
        }

    }

}

