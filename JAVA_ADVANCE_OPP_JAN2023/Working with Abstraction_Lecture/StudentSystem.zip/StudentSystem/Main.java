package StudentSystem;

import java.util.*;

public class Main {

    public static final String EXIT_COMMAND = "Exit";
    public static final String CREATE_COMMAND = "Create";
    public static final String SHOW_COMMAND = "Show";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        StudentSystem base = new StudentSystem();

        String[] input = scanner.nextLine().split(" ");

        while (!(input[0].equals(EXIT_COMMAND))) {

            String name = input[1];
            int age = 0;
            double grade = 0;

            if (input.length > 2) {
                age = Integer.parseInt(input[2]);
                grade = Double.parseDouble(input[3]);
            }

            Student studentInput = new Student();
            studentInput.student(name, age, grade);

            switch (input[0]) {

                case CREATE_COMMAND:

                    base.createStudent(studentInput);

                    break;

                case SHOW_COMMAND:

                    base.showStudent(name);

                    break;

            }

            input = scanner.nextLine().split(" ");

        }
    }

}


