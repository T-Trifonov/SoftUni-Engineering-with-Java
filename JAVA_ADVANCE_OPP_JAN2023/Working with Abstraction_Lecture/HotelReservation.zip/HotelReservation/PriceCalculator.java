package HotelReservation;

public class PriceCalculator {


    public static double calculate(double pricePerDay, int days, Season season, Discount discount) {

        return pricePerDay*days*season.getMultiplier()*discount.getDiscount();

    }
}
