package T02SalaryIncrease;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class Person {

    private String firstName;
    private String lastName;
    private int age;
    private double salary;
    Person(String fistName, String lastName, int age, double salary) {
        this.firstName = fistName;
        this.lastName = lastName;
        this.age = age;
        this.salary= salary;

    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void increaseSalary(double bonus) {

        if (getAge()<30) {
            setSalary(getSalary()*(1+(bonus/100)/2));
        } else {
            setSalary(getSalary()*(1+(bonus/100)));
        }

    }

    @Override
    public String toString() {
        BigDecimal bd = new BigDecimal(getSalary());
        DecimalFormat df = new DecimalFormat("###.0##");

        return String.format("%s %s gets %s leva", firstName, lastName, df.format(bd));
    }
}
